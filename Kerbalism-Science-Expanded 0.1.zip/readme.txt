Kerbalism Science Expanded version 0.1

Created by MIND BULL3TS, based on work by hermano (https://forum.kerbalspaceprogram.com/topic/185337-1125-interkosmos-05-science-parts/?do=findComment&comment=4018857) with help from roadwarrior9's Kerbalism Lab Experiments Expanded (https://forum.kerbalspaceprogram.com/topic/205823-kerbalism-314-kerbalism-lab-experiments-expanded/)

What this mod dones - Converts stock science experiments in supported mod parts to the Duration/Data/Processing system provided by Kerbalism 

Dependencies
-Kerbalism

How To Install:
Extract the folder in the archive and copy to the /gamedata folder located in your KSP installation directory

How To Uninstall:
What?!? You don't like what i made for you?!?!

